# Task Executor UI

React 19 + TypeScript + Ant Design frontend for the Task Executor API.

## Setup

1. `npm install`
2. Copy `.env.example` from backend or set `VITE_API_BASE` environment variable to point to your backend, e.g.

```bash
# linux / mac
export VITE_API_BASE=http://localhost:3000
# windows powershell
$env:VITE_API_BASE = "http://localhost:3000"
```

3. `npm run dev`

Open http://localhost:5173

## Accessibility & Usability notes
- Labels, ARIA attributes and semantic HTML are used for form controls and sections.
- Table rows use `rowKey="id"` and pagination is enabled so the UI remains responsive.
- Execution modal shows copyable stdout/stderr for easy inspection.
